## Version 1.0.2

- Small visual bugfixes and changed the description in icon tab
