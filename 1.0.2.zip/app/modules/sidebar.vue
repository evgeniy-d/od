<template>
  <div>
    Hello Vue Js
  </div>
</template>
<script>
  export default {
    props: ['config' , 'node'],

    module: {
      label:'Merhaba',
      priority:90
    }
  }
</script>
