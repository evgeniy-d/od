<?php if ($view->menu()->exists('main')): ?>
  <?= $view->menu('main' , 'theme:views/theme/navbar/menu.php') ?>
<?php endif; ?>
