<div class="uk-navbar-left">
<?= $view->render('theme:views/theme/navbar/default/navbar-left.php') ?>
</div>

<div class="uk-navbar-center">
<?= $view->render('theme:views/theme/navbar/default/navbar-center.php') ?>
</div>

<div class="uk-navbar-right">
  <?= $view->render('theme:views/theme/navbar/default/navbar-right.php') ?>
  <div class="uk-navbar-item">

  </div>
</div>
