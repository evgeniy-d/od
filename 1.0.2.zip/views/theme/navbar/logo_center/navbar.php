<div class="uk-navbar-center">
<?= $view->render('theme:views/theme/navbar/logo_center/navbar-center.php') ?>
</div>

<div class="uk-navbar-right">
  <?= $view->render('theme:views/theme/navbar/logo_center/navbar-right.php') ?>
</div>
