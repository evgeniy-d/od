<?= $view->render('theme:views/theme/navbar/navbar-others/logo.php' , ['item' => 'uk-navbar-brand']) ?>
