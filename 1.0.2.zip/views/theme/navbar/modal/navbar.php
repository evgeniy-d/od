<div class="uk-navbar-left">
<?= $view->render('theme:views/theme/navbar/modal/navbar-left.php') ?>
</div>

<div class="uk-navbar-right">
  <?= $view->render('theme:views/theme/navbar/modal/navbar-right.php') ?>
</div>
