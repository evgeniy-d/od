<?php

return [

    'installer' => [

        'enabled' => true

    ],

    'application' => [

        'debug' => false

    ],

    'session' => [

        'storage' => 'array'

    ],

    'system/cache' => [

        'storage' => 'array'

    ]

];
