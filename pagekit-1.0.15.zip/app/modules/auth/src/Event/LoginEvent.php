<?php

namespace Pagekit\Auth\Event;

class LoginEvent extends GetResponseEvent
{
}
